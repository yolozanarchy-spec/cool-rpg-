// Integration test of the host/guest protocol with a deterministic mock RTC transport.
// Does NOT replace a real two-network browser test on itch.io.
import {Network} from '../network.js';
import {createState,createPlayer,apply,availableNodes} from '../engine.js';
let num=0;
const offers=new Map();
class MockChannel {
 constructor(){this.readyState='connecting';this.partner=null;this.onmessage=null;this.onopen=null;this.onclose=null;}
 send(data){if(this.partner?.readyState==='open')this.partner.onmessage?.({data});}
 close(){this.readyState='closed';this.onclose?.();}
}
class MockPC {
 constructor(){this.iceGatheringState='complete';this.connectionState='new';this.channel=null;}
 createDataChannel(){this.channel=new MockChannel();return this.channel;}
 async createOffer(){this.offerId='offer-'+(++num);offers.set(this.offerId,this);return {type:'offer',sdp:this.offerId};}
 async createAnswer(){return {type:'answer',sdp:'answer'};}
 async setLocalDescription(d){this.localDescription={...d,sdp:d.sdp+'\na=candidate:1 1 udp 1 127.0.0.1 9999 typ host\n'};}
 async setRemoteDescription(d){this.remoteDescription=d;if(d.type==='offer'){this.parent=offers.get(d.sdp.split('\n')[0]);if(!this.parent)throw Error('Missing offer');this.parent.child=this;}else if(d.type==='answer'){const guest=this.child;if(!guest)throw Error('Missing guest');const guestChannel=new MockChannel();guestChannel.partner=this.channel;this.channel.partner=guestChannel;guest.ondatachannel?.({channel:guestChannel});queueMicrotask(()=>{guestChannel.readyState=this.channel.readyState='open';this.channel.onopen?.();guestChannel.onopen?.();});}}
 close(){this.connectionState='closed';this.channel?.close();}
}
globalThis.RTCPeerConnection=MockPC;
globalThis.btoa=btoa;globalThis.atob=atob;
let host=createState('Host'),guest=null,actionCount=0;
apply(host,{type:'openLobby'},'p0');
const hostNet=new Network({onPeer:()=>{},onMessage:(id,msg)=>{if(msg.type==='join'){host.players.push(createPlayer(id,msg.name,msg.character));hostNet.broadcast(host);}else if(msg.type==='action'){actionCount++;apply(host,msg.action,id);hostNet.broadcast(host);}},onState:()=>{}});
const guestNet=new Network({onPeer:()=>{},onMessage:()=>{},onState:s=>guest=s});
guestNet.localName='Guest';guestNet.localCharacter={race:'Elf',class:'Necromancer',trait:'Lucky'};
const offer=await hostNet.hostOffer();const answer=await guestNet.joinOffer(offer.code);await hostNet.acceptAnswer(offer.id,answer);await new Promise(r=>setTimeout(r,10));
if(host.players.length!==2||guest?.players?.length!==2)throw Error('Lobby synchronization failed');
apply(host,{type:'beginParty'},'p0');hostNet.broadcast(host);if(guest.screen!=='Camp')throw Error('Camp synchronization failed');
// Host-authoritative shared map and guest action synchronization.
apply(host,{type:'navigate',page:'Map'},'p0');hostNet.broadcast(host);
const event=availableNodes(host.map).find(x=>x.type==='Combat')||availableNodes(host.map)[0];apply(host,{type:'chooseNode',id:event.id},'p0');hostNet.broadcast(host);
if(guest.screen!==host.screen)throw Error('Shared map synchronization failed');
guestNet.sendAction({type:'navigate',page:'Character'});if(actionCount!==1)throw Error('Guest action not delivered');
console.log('PASS: host/guest signaling, party join, state sync, shared map, guest action relay');
hostNet.close();guestNet.close();
