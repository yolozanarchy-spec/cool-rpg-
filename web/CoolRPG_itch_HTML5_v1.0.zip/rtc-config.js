// Optional dedicated TURN relay for restrictive NATs / corporate networks.
// Example: export const TURN_SERVERS=[{urls:'turn:relay.example.org:3478',username:'user',credential:'secret'}];
// Leave empty for direct peer-to-peer using public STUN.
export const TURN_SERVERS=[];
