# Icon credits

These SVGs were extracted without altering their contents from the user-provided game-icons.net package. Icons made by the respective original artists.
CC BY 3.0 / CC0 as specified by the original `ICON_CREDITS.txt`.

| Included icon | Creator | Original archive location |
|---|---|---|
| `anvil.svg` | lorc | `icons/ffffff/000000/1x1/lorc/anvil.svg` |
| `archery.svg` | lorc | `icons/ffffff/000000/1x1/lorc/archery-target.svg` |
| `armor.svg` | lorc | `icons/ffffff/000000/1x1/lorc/armor-vest.svg` |
| `arrow.svg` | lorc | `icons/ffffff/000000/1x1/lorc/arrowed.svg` |
| `axe.svg` | lorc | `icons/ffffff/000000/1x1/lorc/fire-axe.svg` |
| `bag.svg` | lorc | `icons/ffffff/000000/1x1/lorc/swap-bag.svg` |
| `barrier.svg` | delapouite | `icons/ffffff/000000/1x1/delapouite/barrier.svg` |
| `bleeding-heart.svg` | lorc | `icons/ffffff/000000/1x1/lorc/bleeding-heart.svg` |
| `bone-knife.svg` | lorc | `icons/ffffff/000000/1x1/lorc/bone-knife.svg` |
| `book.svg` | lorc | `icons/ffffff/000000/1x1/lorc/bookmark.svg` |
| `bow-arrow.svg` | delapouite | `icons/ffffff/000000/1x1/delapouite/bow-arrow.svg` |
| `broadsword.svg` | lorc | `icons/ffffff/000000/1x1/lorc/broadsword.svg` |
| `campfire.svg` | lorc | `icons/ffffff/000000/1x1/lorc/campfire.svg` |
| `chain.svg` | lorc | `icons/ffffff/000000/1x1/lorc/gem-chain.svg` |
| `coin.svg` | lorc | `icons/ffffff/000000/1x1/lorc/crown-coin.svg` |
| `crossbow.svg` | carl-olsen | `icons/ffffff/000000/1x1/carl-olsen/crossbow.svg` |
| `crossed-swords.svg` | lorc | `icons/ffffff/000000/1x1/lorc/crossed-swords.svg` |
| `crown.svg` | lorc | `icons/ffffff/000000/1x1/lorc/crown.svg` |
| `crystal.svg` | lorc | `icons/ffffff/000000/1x1/lorc/crystalize.svg` |
| `dagger.svg` | lorc | `icons/ffffff/000000/1x1/lorc/daggers.svg` |
| `dice.svg` | delapouite | `icons/ffffff/000000/1x1/delapouite/dice-fire.svg` |
| `elven.svg` | pepijn-poolman | `icons/ffffff/000000/1x1/pepijn-poolman/elven-castle.svg` |
| `fire.svg` | sbed | `icons/ffffff/000000/1x1/sbed/fire.svg` |
| `fist.svg` | lorc | `icons/ffffff/000000/1x1/lorc/fist.svg` |
| `flag.svg` | lorc | `icons/ffffff/000000/1x1/lorc/black-flag.svg` |
| `footprint.svg` | lorc | `icons/ffffff/000000/1x1/lorc/footprint.svg` |
| `forest.svg` | delapouite | `icons/ffffff/000000/1x1/delapouite/forest.svg` |
| `ghost.svg` | lorc | `icons/ffffff/000000/1x1/lorc/ghost.svg` |
| `gold.svg` | lorc | `icons/ffffff/000000/1x1/lorc/gold-shell.svg` |
| `hammer.svg` | lorc | `icons/ffffff/000000/1x1/lorc/claw-hammer.svg` |
| `hand.svg` | lorc | `icons/ffffff/000000/1x1/lorc/hand.svg` |
| `heart.svg` | lorc | `icons/ffffff/000000/1x1/lorc/heartburn.svg` |
| `help.svg` | sbed | `icons/ffffff/000000/1x1/sbed/help.svg` |
| `holy-symbol.svg` | lorc | `icons/ffffff/000000/1x1/lorc/holy-symbol.svg` |
| `ice.svg` | lorc | `icons/ffffff/000000/1x1/lorc/ice-bolt.svg` |
| `lightning.svg` | lorc | `icons/ffffff/000000/1x1/lorc/lightning-bow.svg` |
| `magic-swirl.svg` | lorc | `icons/ffffff/000000/1x1/lorc/magic-swirl.svg` |
| `map.svg` | lorc | `icons/ffffff/000000/1x1/lorc/maple-leaf.svg` |
| `mountain.svg` | lorc | `icons/ffffff/000000/1x1/lorc/mountains.svg` |
| `poison.svg` | sbed | `icons/ffffff/000000/1x1/sbed/poison.svg` |
| `potion.svg` | lorc | `icons/ffffff/000000/1x1/lorc/potion-ball.svg` |
| `rune.svg` | lorc | `icons/ffffff/000000/1x1/lorc/rune-sword.svg` |
| `scroll.svg` | lorc | `icons/ffffff/000000/1x1/lorc/tied-scroll.svg` |
| `shield.svg` | sbed | `icons/ffffff/000000/1x1/sbed/shield.svg` |
| `skull.svg` | lorc | `icons/ffffff/000000/1x1/lorc/goo-skull.svg` |
| `spell-book.svg` | delapouite | `icons/ffffff/000000/1x1/delapouite/spell-book.svg` |
| `star.svg` | lorc | `icons/ffffff/000000/1x1/lorc/staryu.svg` |
| `sun.svg` | lorc | `icons/ffffff/000000/1x1/lorc/sun.svg` |
| `sword-clash.svg` | lorc | `icons/ffffff/000000/1x1/lorc/sword-clash.svg` |
| `tower.svg` | lorc | `icons/ffffff/000000/1x1/lorc/tower-fall.svg` |
| `trap.svg` | lorc | `icons/ffffff/000000/1x1/lorc/mantrap.svg` |
| `treasure.svg` | lorc | `icons/ffffff/000000/1x1/lorc/treasure-map.svg` |
| `tree.svg` | lorc | `icons/ffffff/000000/1x1/lorc/evil-tree.svg` |
| `trophy.svg` | lorc | `icons/ffffff/000000/1x1/lorc/trophy.svg` |
| `wings.svg` | lorc | `icons/ffffff/000000/1x1/lorc/angel-wings.svg` |
| `wizard-staff.svg` | lorc | `icons/ffffff/000000/1x1/lorc/wizard-staff.svg` |
| `wolf-head.svg` | lorc | `icons/ffffff/000000/1x1/lorc/wolf-head.svg` |
| `wolf.svg` | lorc | `icons/ffffff/000000/1x1/lorc/werewolf.svg` |
| `zombie.svg` | skoll | `icons/ffffff/000000/1x1/skoll/raise-zombie.svg` |
